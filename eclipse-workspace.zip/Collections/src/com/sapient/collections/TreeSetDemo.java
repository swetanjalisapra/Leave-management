package com.sapient.collections;

public class TreeSetDemo {
public static void main(String[] args) {
	
}
}
