package com.sapient.collections;
import java.util.Date ;
import java.util.Scanner ;
import java.text.* ;
public class DateDemo {
  public static void main(String[] args) throws ParseException {
	Date currentdate = new Date();
	System.out.println(currentdate);
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy");
	Scanner sc  = new Scanner(System.in);
	System.out.println("Enter your D.O.B in this format dd-MM-YY");
	String s = sc.nextLine();
	Date date = dateFormat.parse(s);
	System.out.println(date.getDay());
	
	
}
}
