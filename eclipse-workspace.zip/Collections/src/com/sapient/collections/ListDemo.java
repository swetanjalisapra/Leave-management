package com.sapient.collections;

import java.util.*;
import java.util.ListIterator;
import java.util.ArrayList;

public class ListDemo {
 public static void main(String args[])
 {
	 List<Integer> li = new ArrayList<Integer>();
	 li.add(421);
	 li.add(42);
	 li.add(41);
	 li.add(21);
	 System.out.println(li);
	 int n = li.size();
	 System.out.println(n);
	 System.out.println(li.contains(1));
	 System.out.println(li.isEmpty());
	 
 ListIterator<Integer> it = li.listIterator();
 while(it.hasNext()) {
	 System.out.println(it.next());
 }
 
}}
	