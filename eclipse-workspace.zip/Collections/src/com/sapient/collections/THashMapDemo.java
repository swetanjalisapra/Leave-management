package com.sapient.collections;

import java.util.*;

public class THashMapDemo {
 public static void main(String[] args) {
	Map<Integer,User> map = new HashMap<>();
	User user1 = new User(12,"harish");
	User user2 = new User(13,"ish");
	User user3 = new User(22,"sh");
	User user4 = new User(2,"har");
	map.put(17,user1);
	
	map.put(18,user2);
	map.put(14,user3);
	map.put(15,user4);
	System.out.println(map);
	Set<Map.Entry<Integer,User>> entryset = map.entrySet();
	Iterator<Map.Entry<Integer,User>> it = entryset.iterator();
	while(it.hasNext()) {
		Map.Entry<Integer,User> entry = it.next();
		System.out.println(entry.getKey());
		System.out.println(entry.getValue());
}

	
}
}
