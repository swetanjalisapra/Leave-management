package com.sapine.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;



public class JdbcInsertDemo {
public static void main(String[] args) {
	try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/qe_users","root","Sapra@123.");
		Statement stmt = con.createStatement();
		//stmt.execute("insert into users(name,dept,email) values('sweta','CS','saprasweta')");
		)
	{
		
		
		
		ResultSet resultSet = stmt.executeQuery("select * from users");
		
		while(resultSet.next()) {
		
			int empId = resultSet.getInt("id");	
			String name = resultSet.getString("name");
			System.out.println(empId);
			System.out.println(name);
			
			}
				
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
