package com.sapient.io;
import java.io.*;

public class FileReaderDemo {
public static void main(String[] args) {
	File fi = new File("C:\\text.txt");

	try(FileReader fileReader = new FileReader(fi)) {
		int character=0;
		while(character!=-1) {
			System.out.print((char)character);
			character = fileReader.read();
		}
	}catch(FileNotFoundException e){
		System.out.println(fi.getName());
		e.printStackTrace();
	}
	catch(IOException e){
		System.out.println("io exception");
		e.printStackTrace();
	}
}
}
