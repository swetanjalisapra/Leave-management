package com.sapient.package1;

public class Client {
	public void publicMethod() {
		
	}
	void defaultMethod() {
		
	}
	protected void Method() {
		
	}

}
