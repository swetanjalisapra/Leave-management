package com.sapient.package1;

public class WrapperClassD {
Integer i = 4;
String str = "45";
int intValue = Integer.parseInt(str);
int integerValue = i.intValue();
Integer obj=Integer.valueOf(integerValue);
}
