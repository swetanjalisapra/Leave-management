package com.sapient.package1;

public class PublicClass {
public void publicMethod() {
	
}
void defaultMethod() {
	
}
protected void Method() {
	
}
private void Method1() {
	
}
}
