package com.sapient.lms.client;
import com.sapient.lms.service.LeaveManager;

import java.sql.SQLException;
import java.util.Scanner;


import com.sapient.lms.model.Employee;



public class LeaveManagerClient {
	public static void main(String args[]) throws SQLException {
		
     for(int i=0;i<5;i++) {
    	 System.out.println("Enter hi");
    	 Scanner sc=new Scanner(System.in);
    	 String name = sc.nextLine();
    	 String dept = sc.next();
    	 Employee emp=new Employee(name,dept);
    	 LeaveManager lm=new LeaveManager();
    	 lm.saveEmployee(emp);
     }
 
 
  

  		         
  
  
}}
