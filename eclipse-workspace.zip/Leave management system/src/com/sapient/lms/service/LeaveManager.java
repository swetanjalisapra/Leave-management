package com.sapient.lms.service;
import com.sapient.lms.client.LeaveManagerClient;
import com.sapient.lms.model.Employee;
import com.sapient.lms.exception.InsufficientLeaveBalanceException;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.Connection;
	

public class LeaveManager {
	public void saveEmployee(Employee employee) throws SQLException {
		Connection connection = LeaveManager.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			 preparedStatement = 
					connection.prepareStatement("update employee set leaves=? where id=?");
			// connection.prepareStatement("Delete from employee where name=?");
int	empid=1;
int leaves =2;
			// preparedStatement.setString(1, employee.getDept());
			//preparedStatement.setString(2, employee.getEmp());
			preparedStatement.setInt(1,leaves);
			preparedStatement.setInt(2,empid);
			
			preparedStatement.execute();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			connection.close();
			
		}
	}
	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/qe_users", "root", "Sapra@123.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	
	
	
/*public int applyForLeave(Employee emp,int numOfDays)throws InsufficientLeaveBalanceException {
		 int availableLeaves = emp.getEmpLeaveDetails().getLeaves();
		 if (availableLeaves < numOfDays) {
			 throw new InsufficientLeaveBalanceException("Insufficient leave balance");
		 } else {
			 availableLeaves = availableLeaves - numOfDays;
			 emp.getEmpLeaveDetails().setLeaves(availableLeaves);
		 }
		 return numOfDays;
	 }
	 
	 public int viewLeaveBalance(Employee employee) {
		return  employee.getEmpLeaveDetails().getLeaves();
	 }
	 
	 public void updateLeaves(Employee emp, int numOfDays) {
		 emp.getEmpLeaveDetails().updateLeaves(numOfDays);
		
	 }*/
	 
	
}

