package com.sapient.lms.model;

public class Employee {
      private int id ;
    
      private String emp ;
     
      private String dept ;
 
     
    // private LeaveDetails empLeaveDetails ;
     public Employee(int id,String emp,String dept){
    	  this.id = id;
    	  this.emp = emp;
    	  this.dept = dept;
    	//  this.empLeaveDetails = new LeaveDetails();
      }
     public Employee(String emp,String dept) {
   	  this.emp = emp ;
   	  this.dept = dept ;
   
     }
      
 
      public int getId() {
		return id;
	}

	

	public String getEmp() {
		return emp;
	}

	public void setEmp(String emp) {
		this.emp = emp;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	/*public LeaveDetails getEmpLeaveDetails() {
		return empLeaveDetails;
	}*/

	
}
	
      
      

